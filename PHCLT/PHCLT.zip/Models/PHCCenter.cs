﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PHCLT.Models
{
    public class PHCCenter
    {
        public int Id { get; set; }
        public string Name { get; set; }    
    }
}